﻿using System;

public class Aluno
{
    public string nome;

    public Aluno(string nome)
    {
        this.nome = nome;
    }
}

public class Idade
{
    public int idade;

    public Idade(int idade)
    {
        this.idade = idade;
    }
}

public class RA
{
    public string ra;

    public RA(string ra)
    {
        this.ra = ra;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Aluno aluno = new Aluno("WILGNER");
        Idade idade = new Idade(19);
        RA ra = new RA("F3525I0");

        Console.WriteLine($"Nome do aluno: {aluno.nome}");
        Console.WriteLine($"Idade do aluno: {idade.idade} anos");
        Console.WriteLine($"RA do aluno: {ra.ra}");
    }
}
